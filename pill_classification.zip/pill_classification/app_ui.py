import streamlit as st
import urllib.request
import urllib.parse
import json
import requests
from PIL import Image
from ultralytics import YOLO
import os

# ==================== [환경 설정 및 모델 로드] ====================
# FastAPI 백엔드 서버 주소
MY_PUBLIC_DATA_API_KEY = "49bf6b1eacb94645a25dc723690fb477654232278c78fc1e73dd10941c78690b"

# 2. 학습시킨 오픈소스 YOLOv8 모델 로드
MODEL_PATH = "best.pt" 

@st.cache_resource
def load_yolo_model():
    if os.path.exists(MODEL_PATH):
        return YOLO(MODEL_PATH)
    else:
        return None

model = load_yolo_model()
def fetch_drug_info_directly(drug_name):
    try:
        url = "http://apis.data.go.kr/1471000/DrbEasyDrugInfoService/getDrbEasyDrugList"
        params = {
            "serviceKey": MY_PUBLIC_DATA_API_KEY,
            "itemName": drug_name,
            "type": "json",
            "numOfRows": "1"
        }
        
        # URL 인코딩 처리
        query_string = urllib.parse.urlencode(params, safe='=')
        full_url = f"{url}?{query_string}"
        
        req = urllib.request.Request(full_url)
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode('utf-8'))
            
        items = data.get("body", {}).get("items", [])
        if items:
            return items[0] # 검색된 첫 번째 약 정보 리턴
        return None
    except Exception as e:
        st.error(f"공공데이터 API 통신 중 에러 발생: {str(e)}")
        return None
    
# ==================== [웹 화면 UI 구성] ====================
st.set_page_config(page_title="의약품 식별 시스템", layout="centered")

st.title("의약품 식별 시스템")
st.write("알약 사진을 업로드하면 AI가 성분을 분석하고 복용 주의사항을 안내합니다.")
st.markdown("---")

# [1] 사진 업로드 기능
st.subheader("알약 사진 업로드")
uploaded_file = st.file_uploader("알약 사진을 업로드하세요", type=["jpg", "png", "jpeg"])

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    col1, col2 = st.columns(2)
    
    with col1:
        st.image(image, caption="업로드된 알약 사진", use_container_width=True)
        
    with col2:
        st.info("의약품 분석 중")
        
        # 모델 파일 존재 여부 확인
        if model is None:
            st.error(f"폴더 내에 학습된 모델 파일('{MODEL_PATH}')을 찾을 수 없습니다. 파일명을 확인해 주세요.")
        else:
            # ------------------ [YOLOv8 이미지 분석 처리] ------------------
            # 업로드된 이미지로 객체 탐지 실행 (신뢰도 0.5 이상만 검출)
            results = model.predict(source=image, conf=0.5)
            
            detected_pills = []
            
            # 검출된 결과에서 알약 이름(클래스명) 추출
            for result in results:
                for box in result.boxes:
                    class_id = int(box.cls[0])
                    pill_name = model.names[class_id] # Roboflow에 등록했던 영어/한글 이름
                    if pill_name not in detected_pills:
                        detected_pills.append(pill_name)
            
            # ------------------ [결과 확인 및 서버 통신] ------------------
            if not detected_pills:
                st.warning("사진에서 인식된 알약이 없습니다. 더 선명한 사진을 사용해 주세요.")
            else:
                st.success(f"인식된 알약: {', '.join(detected_pills)}")
                
                # 인식된 알약 중 첫 번째 알약을 기준으로 서버에 정보를 요청합니다.
                target_pill = detected_pills[0]
                
                with st.spinner("공공데이터포털에서 실시간 데이터 조회 중..."):
                    pill_data = fetch_drug_info_directly(target_pill)
                
                if pill_data is not None:
                    st.markdown(f"### 공식 의약품명: **{pill_data.get('itemName', '정보 없음')}**")


                # ------------------ [화면 출력창] ------------------
                    st.markdown(f"### 공식 의약품명: **{pill_data.get('itemName', '정보 없음')}**")
                    
                    # 1. 언제 복용해야 하는지 (효능/효과)
                    st.markdown("#### 1. 효능 및 목적")
                    if pill_data.get('efcyQesitm'):
                        st.info(pill_data['efcyQesitm'].replace("<doc>", "").replace("</doc>", ""))
                    else:
                        st.write("제공된 정보가 없습니다.")
                        
                    # 2. 어떻게 복용하는지 (복용방법)
                    st.markdown("#### 2. 복용방법 및 용량")
                    if pill_data.get('useMethodQesitm'):
                        st.success(pill_data['useMethodQesitm'].replace("<doc>", "").replace("</doc>", ""))
                    else:
                        st.write("제공된 정보가 없습니다.")
                        
                    # 3. 복용 시 주의사항
                    st.markdown("#### 3. 복용 시 주의사항")
                    if pill_data.get('atpnQesitm'):
                        st.error(pill_data['atpnQesitm'].replace("<doc>", "").replace("</doc>", ""))
                    else:
                        st.write("제공된 정보가 없습니다.")
